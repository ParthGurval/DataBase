<?php

//main connection file for both admin & front end
$servername = "database-1.<RDS_ENDPOINT>.rds.amazonaws.com"; 
$username = "admin"; // RDS master username
$password = "AdminUser1234"; // RDS master password
$dbname = "GroceryShopping";  // database name

// Create connection
$db = mysqli_connect($servername, $username, $password, $dbname); // connecting 
// Check connection
if (!$db) {       // checking connection to DB 
    die("Connection failed: " . mysqli_connect_error());
}

// Make sure that the security group allows inbound connections on port 3306 (default MySQL port).

?>
